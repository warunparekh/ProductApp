using ProductApp.Models;
using ProductApp.Repositories;

namespace ProductApp.Services
{
    public class DatabaseSeeder
    {
        private readonly UserRepository _userRepository;
        private readonly CategoryRepository _categoryRepository;
        private readonly ProductRepository _productRepository;
        private readonly AuthService _authService;

        public DatabaseSeeder(
            UserRepository userRepository,
            CategoryRepository categoryRepository,
            ProductRepository productRepository,
            AuthService authService)
        {
            _userRepository = userRepository;
            _categoryRepository = categoryRepository;
            _productRepository = productRepository;
            _authService = authService;
        }

        public async Task SeedAsync()
        {
            // Create admin user
            var adminEmail = "admin@productapp.com";
            if (!_userRepository.EmailExists(adminEmail))
            {
                var admin = new User
                {
                    UserName = "Administrator",
                    UserEmail = adminEmail,
                    UserPassword = "Admin@123",
                    UserNumber = 1234567890,
                    UserAddress = "Admin Address",
                    isAdmin = true
                };
                
                admin.UserPassword = _authService.HashPassword(admin.UserPassword);
                admin.CreationDate = DateTime.Now;
                _userRepository.AddUser(admin);
            }

            // Create sample categories
            var categories = new List<Category>
            {
                new Category { CategoryName = "Electronics" },
                new Category { CategoryName = "Clothing" },
                new Category { CategoryName = "Books" },
                new Category { CategoryName = "Home & Garden" }
            };

            foreach (var category in categories)
            {
                var existingCategories = _categoryRepository.GetAllCategories();
                if (!existingCategories.Any(c => c.CategoryName == category.CategoryName))
                {
                    _categoryRepository.AddCategory(category);
                }
            }

            // Create sample products
            var allCategories = _categoryRepository.GetAllCategories().ToList();
            if (allCategories.Any())
            {
                var sampleProducts = new List<Product>
                {
                    new Product
                    {
                        ProductName = "Laptop",
                        ProductDescription = "High-performance laptop for work and gaming",
                        ProductPrice = 999,
                        ProductStock = 10,
                        CategoryId = allCategories.First(c => c.CategoryName == "Electronics").CategoryId,
                        ProductImage = "https://via.placeholder.com/300x200?text=Laptop"
                    },
                    new Product
                    {
                        ProductName = "T-Shirt",
                        ProductDescription = "Comfortable cotton t-shirt",
                        ProductPrice = 29,
                        ProductStock = 50,
                        CategoryId = allCategories.First(c => c.CategoryName == "Clothing").CategoryId,
                        ProductImage = "https://via.placeholder.com/300x200?text=T-Shirt"
                    },
                    new Product
                    {
                        ProductName = "Programming Book",
                        ProductDescription = "Learn C# programming with this comprehensive guide",
                        ProductPrice = 49,
                        ProductStock = 25,
                        CategoryId = allCategories.First(c => c.CategoryName == "Books").CategoryId,
                        ProductImage = "https://via.placeholder.com/300x200?text=Book"
                    }
                };

                foreach (var product in sampleProducts)
                {
                    var existingProducts = _productRepository.GetAllProducts();
                    if (!existingProducts.Any(p => p.ProductName == product.ProductName))
                    {
                        _productRepository.AddProduct(product);
                    }
                }
            }
        }
    }
}