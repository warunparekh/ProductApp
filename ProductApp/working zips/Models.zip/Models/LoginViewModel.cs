﻿using System.ComponentModel.DataAnnotations;

namespace ProductApp.Models
{
    public class LoginViewModel
    {
        [Required]
        [EmailAddress]
        public string UserEmail { get; set; }

        [Required]
        [DataType(DataType.Password)]
        public string UserPassword { get; set; }
    }
}