﻿using System.ComponentModel.DataAnnotations;

namespace ProductApp.Models
{
    public class RegisterViewModel
    {
        [Required]
        public string UserName { get; set; }

        [Required]
        [RegularExpression(@"^\d+$", ErrorMessage = "Number must be digits only.")]
        public string UserNumber { get; set; }

        [Required]
        [EmailAddress]
        public string UserEmail { get; set; }

        [Required]
        [DataType(DataType.Password)]
        public string UserPassword { get; set; }

        [Required]
        public string UserAddress { get; set; }
    }
}