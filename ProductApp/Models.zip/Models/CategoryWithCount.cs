namespace ProductApp.Models
{
    public class CategoryWithCount
    {
        public int CategoryId { get; set; }
        public string CategoryName { get; set; }
        public int ProductCount { get; set; }
    }
}